import React, {useState} from "react";

function TodoList() {

    const [todo, setTodo] = useState({
        description: "",
        date: ""
    });

    const[todos, setTodos] = useState([]);

    const handleclick = () => {
        if(todo.description && todo.date) {
            setTodos([...todos,todo]);
            setTodo({description:"" ,date: ""  });
        }else {
            alert("Type a description first");
        }
        
    };

    const handleDelete = (index) => {
        setTodos(todos.filter((todo, i) => i !== index));
    };

  return ( 
  <React.Fragment> 

    <label htmlFor="description"> Description:</label>
    
    <input
    id ="description"
    placeholder = "Description"
    value = {todo.description}
    onChange ={e => setTodo({...todo,description: e.target.value})}
    />

<label htmlFor="date"> Date:</label>

    <input
    id="date"
    type="date"
    value={todo.date}
    onChange= {e => setTodo({...todo,date: e.target.value})}
    />
    <button onClick = {handleclick}>Add Todo</button>

    <table>

<thead>
<tr>
<th> Description</th>
<th>Date</th>

    </tr>
</thead>
        <tbody>
            {todos.map((todo,index) => (
                <tr key ={index}>
                    <td>{todo.description}</td>
                    <td>{todo.date}</td>
                    <td> <button onClick={() => handleDelete(index)}>Delete</button>
                    </td>
                </tr>
            ))}
        </tbody>
    </table>

</React.Fragment>
  );
}

export default TodoList;