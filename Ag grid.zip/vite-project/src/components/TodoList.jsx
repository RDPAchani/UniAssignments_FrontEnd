import React from "react";
import { AgGridReact } from "ag-grid-react";


import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-material.css";




import { useRef, useState } from "react";

function TodoList() {
  const [todo, setTodo] = useState({
    description: "",
    date: "",
    priority: "",
  });
  const [todos, setTodos] = useState([]);
  const gridRef = useRef();
  const handleAdd = () => {
    if (todo.description && todo.date && todo.priority) {
      setTodos([...todos, todo]);
      setTodo({ description: "", date: "", priority: "" });
    } else {
      alert("Type a description, priority and date first");
    }
  };

  const [columnDefs, setColumnDefs] = useState([
    { field: "description", sortable: true, filter: true, editable: true },
    {
      field: "priority",
      sortable: true,
      editable: true,
      filter: true,
      cellStyle: (params) =>
        params.value === "High" || params.value === "high"
          ? { color: "red" }
          : { color: "black" },
    },
    { field: "date", sortable: true, filter: true, editable: true },
  ]);
  const handleDelete = () => {
    if (gridRef.current.getSelectedNodes().length > 0) {
      setTodos(
        todos.filter(
          (todo, index) => index != gridRef.current.getSelectedNodes()[0].id
        )
      );
      
    } else {
      alert("Select a row first");
    }
    
  };

  const handleDateChange = (date) => {
    const isoDateString = new Date(date).toISOString();
    setTodo({ ...todo, date: isoDateString });

  };
  return (
    <>
    <input
          placeholder="Description"
          value={todo.description}
          onChange={(e) => setTodo({ ...todo, description: e.target.value })}
        />

        <input
          placeholder="Priority"
          value={todo.priority}
          onChange={(e) => setTodo({ ...todo, priority: e.target.value })}
        />

        <input
          placeholder="Date"
          value={todo.date}
        onChange={e => setTodo({...todo, date: e.target.value })}
       
        />

<button onClick={handleAdd}>Add</button>
      <button onClick={handleDelete}>Delete</button>
      
      <div className="ag-theme-material" style={{ width: 700, height: 500 }}>
        <AgGridReact
          ref={gridRef}
          onGridReady={(params) => (gridRef.current = params.api)}
          rowData={todos}
          columnDefs={columnDefs}
          rowSelection="single"
        />
      </div>
      </>
    
  );
}

export default TodoList;