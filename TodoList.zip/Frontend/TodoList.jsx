import React, {useState} from "react";

function TodoList() {

    const [description, setDescription] = useState("");
    const[todos, setTodos] = useState([]);

    const handleclick = () => {
        if(description) {
            setTodos([...todos,description]);
            setDescription("");
        }else {
            alert("Type a description first");
        }
        
    };

  return ( 
  <React.Fragment> 
    
    <input

    placeholder = "Description"
    value = {description}
    onChange ={e => setDescription(e.target.value)}
    />
    <button onClick = {handleclick}>Add Todo</button>

    <table>

        <tbody>
            {todos.map((todo,index) => (
                <tr key ={index}>
                    <td>{todo}</td>
                </tr>
            ))}
        </tbody>
    </table>

</React.Fragment>
  );
}

export default TodoList;