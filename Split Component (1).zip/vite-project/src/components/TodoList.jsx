import React, {useState} from "react";
import TodoTable from "./TodoTable";

function TodoList() {

    const [todo, setTodo] = useState({
        description: "",
        date: ""
    });

    const[todos, setTodos] = useState([]);
    const [desc, setDesc] = useState("");

    const handleChange = (e) =>
    {
        setDesc(e.target.value);
    };


    const addTodo = () => {
        if(todo.description && todo.date) {
            setTodos([...todos,todo]);
            setTodo({description:"" ,date: ""  });
        }else {
            alert("Type a description first");
        }
        
    };

    const handleDelete = (index) => {
        setTodos(todos.filter((_, i) => i !== index));
    };

  return ( 
  <React.Fragment> 

    <label htmlFor="description"> Description:</label>
    
    <input
    id ="description"
    placeholder = "Description"
    value = {todo.description}
    onChange ={e => setTodo({...todo,description: e.target.value})}
    />

<label htmlFor="date"> Date:</label>

    <input
    id="date"
    type="date"
    value={todo.date}
    onChange= {e => setTodo({...todo,date: e.target.value})}
    />
    

    
    <button onClick={addTodo}>Add</button>
    <TodoTable todos={todos} onDelete={handleDelete} />
  


</React.Fragment>
  );
}

export default TodoList;