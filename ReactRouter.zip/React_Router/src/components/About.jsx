export default function About() {
  
    return (
      <h1>With my app you can...</h1>
    );
  }

  