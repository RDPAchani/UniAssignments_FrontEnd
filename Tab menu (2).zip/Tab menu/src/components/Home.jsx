import React from 'react';
import Typography from '@mui/material/Typography';

function Home() {
  return (
    <Typography>Welcome</Typography>
  );
}

export default Home;