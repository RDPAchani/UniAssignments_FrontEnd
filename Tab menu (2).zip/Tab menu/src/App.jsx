
import './App.css'
import BasicTabs from "./components/BasicTabs";

import * as React from 'react';
 

  function App() {
    return (
      <div className="App">
        <h1>My Todos</h1>
      
        <BasicTabs />
      </div>
    );
  }
  
  export default App;